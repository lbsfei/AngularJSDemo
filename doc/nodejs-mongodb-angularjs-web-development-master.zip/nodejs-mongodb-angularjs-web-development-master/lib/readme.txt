These files have been removed. Instead use the following CDN locations for AngularJS and jQuery:
*  http://code.angularjs.org/1.2.9/angular.min.js
*  http://code.angularjs.org/1.2.9/angular-animate.min.js
*  http://code.angularjs.org/1.2.9/angular-animate.min.js
*  http://code.angularjs.org/1.2.9/angular-cookies.min.js
*  http://code.jquery.com/jquery-1.11.0.min.js
